const showStars = () => {
    document.getElementById('container__stars-box').style.visibility = 'visible'
}

const hideStars = () => {
    document.getElementById('container__stars-box').style.visibility = 'hidden'
}